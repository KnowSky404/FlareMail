FlareMail brand kit / 品牌资源包

Telegram 头像推荐 / Recommended Telegram avatar:
  flaremail-avatar-orange.jpg

三种头像配色 / Three avatar colors: orange, light, dark.
头像 / Avatars: 1024 x 1024 JPG, PNG, SVG.
保持完整画面上传，不要放大裁切。 / Keep the full frame when uploading.
JPG/PNG 头像背景不透明。 / Avatar JPG/PNG backgrounds are opaque.

透明图标 / Transparent mark: flaremail-mark.png (1024 x 1024)
透明横版 / Transparent lockup: flaremail-logo.png (2288 x 512)
SVG 原始文件 / Original vectors: flaremail-mark.svg, flaremail-logo.svg
矢量 PDF / Vector PDFs: flaremail-mark.pdf, flaremail-logo.pdf
预览 / Preview: avatar-preview.jpg

横版适合浅色背景。 / Use the horizontal logo on light backgrounds.
PNG/PDF 横版字体 / Horizontal PNG/PDF font: Liberation Sans (Arial substitute).
PDF 使用 RGB 品牌色，未转换为 CMYK 或专色。
PDFs retain RGB brand colors; no CMYK or spot-color conversion.
品牌色 / Colors: #F48120, #1D1D1F, #FFFFFF.
许可证 / License: AGPL-3.0-or-later, see LICENSE.
